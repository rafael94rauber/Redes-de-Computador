﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chatSocketClient
{
    class Program
    {
        // usuario que estao envolvidos na troca de mensagem
        public const string USUARIO_ENVIO = "MARCIO - PROFESSOR";
        public const string USUARIO_RECEBE = "RAUBER - ALUNO";

        static void Main(string[] args)
        {
            var clinte = new Cliente();
            clinte.ExecutarCliente(USUARIO_ENVIO, USUARIO_RECEBE);
        }
    }
}
