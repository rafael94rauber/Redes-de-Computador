﻿namespace ClientApp
{
    public class Usuario
    {
        public string Senha { get; set; }

        public string Login { get; set; }

        public string NomeUsuario { get; set; }

        public string NomeGrupo { get; set; }
        public string IdGrupo { get; set; }
    }
}