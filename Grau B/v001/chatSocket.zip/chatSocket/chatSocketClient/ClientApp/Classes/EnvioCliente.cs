﻿namespace ClientApp
{
    public class EnvioCliente
    {
        public bool SomenteListarTodasMensagens { get; set; }
        public string NomeClienteRecebe { get; set; }
        public string NomeClienteEnvia { get; set; }
        public string Mensagem { get; set; }
        public bool DesligarCliente { get; set; }
    }
}
