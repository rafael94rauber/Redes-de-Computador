﻿using System.Collections.Generic;

namespace ClientApp
{
    public class RespostaServidor
    {
        public List<EnvioCliente> ConteudoServidor { get; set; }
        public bool PararCliente { get; set; }
    }
}
