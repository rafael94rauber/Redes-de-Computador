﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ClientApp.Classes
{
    public class EnviarServidor
    {
        public TipoComunicao TiposComunicacao { get; set; }

        public JsonTextReader ObjetoJson { get; set; }

        public string StringJson { get; set; }

        public enum TipoComunicao : byte
        {
            Login = 0x00,
            EnviarMensagem = 0x001,
            ReceberMensagem = 0x002
        }
    }
}
