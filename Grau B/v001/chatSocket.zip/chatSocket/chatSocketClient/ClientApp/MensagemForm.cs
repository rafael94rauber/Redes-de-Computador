﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientApp
{
    public partial class MensagemForm : Form
    {
        public Usuario UsuarioLogadoAplicativo;
        public Usuario UsuarioForaAplicativo;

        private StringBuilder MensagensEnviadas = new StringBuilder();
        private StringBuilder MensagensRecebidas = new StringBuilder();

        public MensagemForm()
        {
            InitializeComponent();
        }

        private void MensagemForm_Load(object sender, EventArgs e)
        {
            MensagensEnviadas = new StringBuilder();
            MensagensRecebidas = new StringBuilder();

            LblUsuarioEnvio.Text = $"{LblUsuarioEnvio.Text}: {UsuarioLogadoAplicativo.NomeUsuario}";
            LblUsuarioReceber.Text = $"{LblUsuarioReceber.Text}: {UsuarioForaAplicativo.NomeUsuario}";
            lblEnviar.Text = $"De: {UsuarioLogadoAplicativo.NomeGrupo} Para: {UsuarioForaAplicativo.NomeUsuario}";
        }

        private void BtnEnviar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtEnviar.Text))
            {
                return;
            }            
        }

        private void BtnReceber_Click(object sender, EventArgs e)
        {

        }
    }
}
