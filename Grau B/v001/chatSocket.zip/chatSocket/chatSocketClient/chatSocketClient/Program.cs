﻿

namespace chatSocketClient
{
    public class Program
    {
        // usuario que estao envolvidos na troca de mensagem
        public const string USUARIO_ENVIO = "RAUBER - ALUNO";
        public const string USUARIO_RECEBE = "MARCIO - PROFESSOR";
        static void Main(string[] args)
        {
            var clinte = new Cliente();
            // clinte.ExecutarCliente(USUARIO_ENVIO, USUARIO_RECEBE);

            clinte.Login(new EnvioLogin()
            {
                Usuario = "rrauber",
                Senha = "123"                
            });
        }        
    }
}
