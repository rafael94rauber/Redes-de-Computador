﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace chatSocketClient
{
    public class Cliente
    {
        public const string IP_SERVIDOR = "10.80.1.97";
        public const Int32 PORTA_SERVIDOR = 13000;
        public BinaryWriter enviaServidor;
        public BinaryReader recebeServidor;


        public TcpClient AbrirConexaoServidor()
        {
            var servidorLigado = false;
            var contaTentativas = 0;

            IPAddress localAddr = IPAddress.Parse(IP_SERVIDOR);
            TcpClient client = new TcpClient();
            IPEndPoint serverLocation = new IPEndPoint(localAddr, PORTA_SERVIDOR);

            while (!servidorLigado)
            {
                try
                {
                    client.Connect(serverLocation);
                    servidorLigado = true;
                }
                catch (SocketException)
                {
                    contaTentativas += 1;
                    Console.WriteLine("Servidor esta desligado");

                    if (contaTentativas == 10)
                    {
                        client.Close();
                        return client;
                    }
                    // Aguardar 2 segundos o servidor ser iniciado
                    System.Threading.Thread.Sleep(2000);
                }
            }

            return client;
        }

        // -------------- LOGIN ------------------------------------ // 

        public Usuario Login(EnvioLogin login)
        {
            var conexaoCliente = AbrirConexaoServidor();
            var conexaoClienteServidor = conexaoCliente.GetStream();

            enviaServidor = new BinaryWriter(conexaoClienteServidor);
            recebeServidor = new BinaryReader(conexaoClienteServidor);

            var respostaLoginServidor = ValidarLoginServidor(login);

            while (respostaLoginServidor is null)
            {
                respostaLoginServidor = ValidarLoginServidor(login);
            }

            enviaServidor.Close();
            recebeServidor.Close();
            conexaoClienteServidor.Close();
            conexaoCliente.Close();

            return respostaLoginServidor;
        }

        private Usuario ValidarLoginServidor(EnvioLogin login)
        {
            ComunicacaoServidor montaDadosEnvioServidor = new ComunicacaoServidor()
            {
                TiposComunicacao = ComunicacaoServidor.TipoComunicao.Login,
                StringJson = JsonConvert.SerializeObject(login)
            };

            // Manda para o servidor
            enviaServidor.Write(JsonConvert.SerializeObject(montaDadosEnvioServidor));

            // resposta do servidor            
            var messageRespostaServidor = recebeServidor.ReadString();
            if (string.IsNullOrEmpty(messageRespostaServidor))
            {
                return null;
            }

            RespostaServidorLogin retornoServidor = JsonConvert.DeserializeObject<RespostaServidorLogin>(messageRespostaServidor);

            if (retornoServidor.Usuario.Login == login.Usuario && retornoServidor.Usuario.Senha == login.Senha)
            {
                return retornoServidor.Usuario;
            }

            return null;
        }

        // -------------- LOGIN ------------------------------------ // 

        // -------------- ENVIAR MENSAGEM SERVIDOR ----------------- // 

        public void EnviarMensagemPrivadoServidor()
        {
            // mensagem 
            // usuario envio 
            // usuario receber            
        }

        public void EnviarMensagemGrupoServidor()
        {
            // mensagem 
            // usuario envio 
            // usuario receber            
        }


        // -------------- ENVIAR MENSAGEM SERVIDOR ----------------- // 



        public void ExecutarCliente11111(string NomeClienteEnvia, string NomeClienteRecebe)
        {


            StringBuilder todasMensagens = new StringBuilder();
            var pararCliente = false;
            var cliente = AbrirConexaoServidor();
            var conexaoClienteServidor = cliente.GetStream();

            enviaServidor = new BinaryWriter(conexaoClienteServidor);
            recebeServidor = new BinaryReader(conexaoClienteServidor);

            do
            {
                Console.Clear();
                Console.WriteLine("");
                Console.WriteLine("--------------------------------------");
                Console.WriteLine($"Usuario(De): {NomeClienteEnvia} <---PARA---> Usuario(para): {NomeClienteRecebe}");
                Console.WriteLine("--------------------------------------");
                Console.WriteLine("");
                Console.Write("Mensagem: ");
                var conteudoMensagem = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(conteudoMensagem))
                {
                    Console.Clear();
                    Console.WriteLine("");
                    Console.WriteLine("Opcao invalida, Digite a mensagem");
                    Console.WriteLine("");
                    Thread.Sleep(500);
                    continue;
                }

                EnvioCliente envioCliente = new EnvioCliente()
                {
                    SomenteListarTodasMensagens = false,
                    DesligarCliente = false,
                    Mensagem = conteudoMensagem,
                    NomeClienteEnvia = NomeClienteEnvia,
                    NomeClienteRecebe = NomeClienteRecebe
                };

                var respostaServidor = EnviarParaServidor(envioCliente);

                if (respostaServidor.PararCliente)
                {
                    pararCliente = true;
                    continue;
                }

                pararCliente = EscreverMensagemTela(respostaServidor.ConteudoServidor, NomeClienteEnvia);

                Console.WriteLine("Enviar Mensagem: SIM(1) ou NAO(2)");
                var opcaoUsario = Console.ReadLine();

                if (opcaoUsario.Equals("1") || opcaoUsario.ToUpper().Equals("SIM"))
                {
                    continue;
                }
                else if (opcaoUsario.Equals("2") || opcaoUsario.ToUpper().Equals("NAO"))
                {
                    Console.Clear();
                    Console.WriteLine("Listar Mensagem do Servidor: SIM(1) ou NAO(2)");
                    opcaoUsario = Console.ReadLine();

                    if (opcaoUsario.Equals("1") || opcaoUsario.ToUpper().Equals("SIM"))
                    {
                        envioCliente = new EnvioCliente()
                        {
                            SomenteListarTodasMensagens = true,
                            DesligarCliente = false,
                            Mensagem = null,
                            NomeClienteEnvia = NomeClienteEnvia,
                            NomeClienteRecebe = NomeClienteRecebe
                        };

                        respostaServidor = EnviarParaServidor(envioCliente);

                        if (respostaServidor.PararCliente)
                        {
                            pararCliente = true;
                            continue;
                        }

                        pararCliente = EscreverMensagemTela(respostaServidor.ConteudoServidor, NomeClienteEnvia);
                    }

                    if (!pararCliente)
                    {
                        //aguarda 15 segundos e retorna para o envio de mensagem
                        Console.WriteLine($"Aguardando Cliente: {NomeClienteRecebe}, Responder o servidor");
                        Thread.Sleep(15000);
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("");
                    Console.WriteLine("Opcao Invalida");
                    Console.WriteLine("");
                    Console.WriteLine("Aguarde para escrever uma nova mensagem");
                    Console.WriteLine("");
                    // 5 segundos esperando o outro cliente enviar uma resposata
                    // depois o cliente atual manda uma nova mensagem
                    Thread.Sleep(5000);
                }
            } while (!pararCliente);

            enviaServidor.Close();
            recebeServidor.Close();
            conexaoClienteServidor.Close();
            cliente.Close();
        }

        private bool EscreverMensagemTela(List<EnvioCliente> conteudoServidor, string NomeClienteEnvia)
        {
            var pararCliente = false;
            //escreve as mensagens recebidas na tela do cliente
            StringBuilder mensagemTela = new StringBuilder();
            mensagemTela.AppendLine($"Total de Mensagens Trocadas:{conteudoServidor.Count}");
            mensagemTela.AppendLine("");
            mensagemTela.AppendLine("--------------------BLOCO DE MENSAGENS--------------------");
            mensagemTela.AppendLine("");
            mensagemTela.AppendLine("Usuario(De): [USUARIO_ENVIO] <---PARA---> Usuario(para): [USUARIO_RECEBE]");
            mensagemTela.AppendLine("");

            var recebeuMensagem = false;
            var usuarioEnvio = string.Empty;
            var usuarioRecebe = string.Empty;

            foreach (var item in conteudoServidor)
            {
                pararCliente = item.DesligarCliente;
                if (pararCliente)
                {
                    break;
                }

                if (NomeClienteEnvia == item.NomeClienteEnvia)
                {
                    continue;
                }

                if (item.Mensagem is null)
                {
                    continue;
                }


                mensagemTela.AppendLine("");
                mensagemTela.AppendLine($"Mensagem: {item.Mensagem}");
                mensagemTela.AppendLine("");
                recebeuMensagem = true;
                usuarioEnvio = item.NomeClienteEnvia;
                usuarioRecebe = item.NomeClienteRecebe;
            }

            if (!recebeuMensagem)
            {
                mensagemTela.AppendLine("");
                mensagemTela.AppendLine("--------------------VOCE NAO RECEBEU MENSAGEM NO SERVIDOR--------------------");
                mensagemTela.AppendLine("");
            }

            mensagemTela.AppendLine("");
            mensagemTela.AppendLine("--------------------BLOCO DE MENSAGENS--------------------");
            Console.WriteLine(mensagemTela.
                ToString().
                Replace("[USUARIO_ENVIO]", usuarioEnvio).
                Replace("[USUARIO_RECEBE]", usuarioRecebe)
            );

            return pararCliente;
        }

        private RespostaServidor EnviarParaServidor(EnvioCliente envioCliente)
        {        
            RespostaServidor retornoServidor = new RespostaServidor();
            // manda para o servidor
            var montaEnvioServidor = JsonConvert.SerializeObject(envioCliente);
            enviaServidor.Write(montaEnvioServidor);

            // resposta do servidor
            var messageRespostaServidor = recebeServidor.ReadString();
            if (string.IsNullOrEmpty(messageRespostaServidor))
            {
                retornoServidor.PararCliente = true;
                retornoServidor.ConteudoServidor = null;
                return retornoServidor;
            }

            var conteudoServidor = JsonConvert.DeserializeObject<List<EnvioCliente>>(messageRespostaServidor);

            if (conteudoServidor is null)
            {
                retornoServidor.PararCliente = true;
                retornoServidor.ConteudoServidor = null;
                return retornoServidor;
            }

            retornoServidor.PararCliente = false;
            retornoServidor.ConteudoServidor = conteudoServidor;
            return retornoServidor;
        }        
    }
}
