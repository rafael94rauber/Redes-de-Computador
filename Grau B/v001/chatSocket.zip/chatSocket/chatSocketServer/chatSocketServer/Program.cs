﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Threading;
using Newtonsoft.Json;
using System.Reflection;

namespace chatSocketServer
{
    class Program
    {

        public const string IP_SERVIDOR = "10.80.1.97";
        public const Int32 PORTA_SERVIDOR = 13000;
        public static Dictionary<Guid, EnviaMensagemCliente> MensagensTrocadas;
        public static Thread instanciaServidorThread = null;
        public static List<Usuario> ListaUsuarios = null;
        public static bool FinalizarServidor = false;

        public static int quantidadeClientesConectados = 0;

        static void Main(string[] args)
        {
            Console.WriteLine("Iniciando servidor.....");

            ListaUsuarios = CarregaBaseUsuarios();

            MensagensTrocadas = new Dictionary<Guid, EnviaMensagemCliente>();
            IPAddress localAddr = IPAddress.Parse(IP_SERVIDOR);
            var server = new TcpListener(localAddr, PORTA_SERVIDOR);

            server.Start();

            //PROGRAMADO PARA RECEBER 2 THREAD DE CLIENTES
            for (int index = 1; index <= ListaUsuarios.Count; index++)
            {
                var nome = $"instancia:{index}; guid: {GerarGuid()};";
                instanciaServidorThread = new Thread(() => Servidor(server, nome))
                {
                    Name = nome
                };

                instanciaServidorThread.Start();
            }

            Console.WriteLine("Servidor ligado");
            var dataHoraServidorLigado = DateTime.Now;
            while (instanciaServidorThread.IsAlive)
            {
                if ( (dataHoraServidorLigado - DateTime.Now).TotalSeconds > 30 )
                {                    
                    Console.WriteLine("Servidor ligado");
                    Console.WriteLine($"Aplicacoes conectadas no servidor: {quantidadeClientesConectados}");
                    dataHoraServidorLigado = DateTime.Now;
                }
                Thread.Sleep(100);
            }

            server.Stop();
        }

        private static void Servidor(TcpListener server, string nomeInstancia)
        {
            while (!FinalizarServidor)
            {
                var conexao = server.AcceptSocket();
                quantidadeClientesConectados += 1;
                var socketStream = new NetworkStream(conexao);
                var recebeServidor = new BinaryReader(socketStream);
                var enviaServidor = new BinaryWriter(socketStream);

                do
                {
                    Console.WriteLine($"Servidor comunicando com o clinte: {nomeInstancia}");
                    string conteudo = null;

                    try
                    {
                        conteudo = recebeServidor.ReadString();
                    }
                    catch (IOException)
                    {
                        Console.WriteLine($"Cliente desconectou da instancia: {nomeInstancia}");
                        continue;
                    }

                    if (string.IsNullOrEmpty(conteudo))
                    {
                        enviaServidor.Write(string.Empty);
                        conexao.Disconnect(true);
                        Console.WriteLine($"Servidor desconectado: {nomeInstancia}");
                        continue;
                    }

                    var recebeCliente = JsonConvert.DeserializeObject<ComunicacaoServidor>(conteudo);

                    if (recebeCliente is null)
                    {
                        enviaServidor.Write(string.Empty);
                        Console.WriteLine($"Servidor desconectado: {nomeInstancia}");
                        continue;
                    }

                    switch (recebeCliente.TiposComunicacao)
                    {
                        case ComunicacaoServidor.TipoComunicao.Login:
                            var usuario = ValidarLogin(JsonConvert.DeserializeObject<RecebeLoginCliente>(recebeCliente.StringJson));

                            RespostaServidorLogin respostaLogin = new RespostaServidorLogin()
                            {
                                Usuario = usuario
                            };

                            //responde o cliente
                            enviaServidor.Write(JsonConvert.SerializeObject(respostaLogin));
                            break;

                        case ComunicacaoServidor.TipoComunicao.EnviarMensagem:
                            var idMensagem = GerarGuid();
                            //MensagensTrocadas.Add(idMensagem, recebeCliente);

                            List<EnviaMensagemCliente> respostaServidor = new List<EnviaMensagemCliente>();
                            //foreach (var item in MensagensTrocadas)
                            //{
                            //    respostaServidor.Add(item.Value);
                            //}

                            enviaServidor.Write(JsonConvert.SerializeObject(respostaServidor));
                            break;
                        case ComunicacaoServidor.TipoComunicao.ReceberMensagem:
                            break;
                        default:
                            enviaServidor.Write(JsonConvert.SerializeObject(null));
                            break;
                    }                                       
                } while (conexao.Connected);

                enviaServidor.Close();
                recebeServidor.Close();
                socketStream.Close();
                conexao.Close();
                quantidadeClientesConectados -= 1;
            }
        }

        private static Guid GerarGuid()
        {
            return Guid.Parse(Guid.NewGuid().ToString("B"));
        }

        public static List<Usuario> CarregaBaseUsuarios()
        {
            List<Usuario> ListaUsuarios = null;
            using (StreamReader ConteudoArquivo = new StreamReader($"{CaminhoAplicacao}\\usuariosSenhas.json"))
            {
                ListaUsuarios = JsonConvert.DeserializeObject<List<Usuario>>(ConteudoArquivo.ReadToEnd());
            }

            return ListaUsuarios;
        }

        public static string CaminhoAplicacao
        {
            get
            {
                string codeBase = Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }

        public static Usuario ValidarLogin(RecebeLoginCliente login)
        {
            var usuario = ListaUsuarios.Where(x => x.Login == login.Usuario && x.Senha == login.Senha).FirstOrDefault();

            return usuario;
        }
    }
}
